# Инструкции по загрузке в GitHub

## ⚠️ ВАЖНО: Безопасность токена

**Токен доступа был раскрыт публично и должен быть немедленно отозван!**

### Шаги по отзыву токена:
1. Войдите в GitHub → Settings → Developer settings → Personal access tokens
2. Найдите и удалите токен: `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`
3. Создайте новый токен с необходимыми правами

## Ручная загрузка репозитория

### Вариант 1: Через веб-интерфейс GitHub

1. **Создайте новый репозиторий:**
   - Перейдите на https://github.com/nvzar
   - Нажмите "New repository"
   - Название: `host-security-homework`
   - Описание: "Домашнее задание: Защита хоста"
   - Выберите "Public" или "Private"
   - НЕ инициализируйте с README, .gitignore или лицензией

2. **Загрузите файлы:**
   - Скопируйте содержимое всех файлов из локального репозитория
   - Создайте файлы в веб-интерфейсе GitHub

### Вариант 2: Через командную строку (с новым токеном)

1. **Создайте новый Personal Access Token:**
   - GitHub → Settings → Developer settings → Personal access tokens → Tokens (classic)
   - Generate new token (classic)
   - Выберите scope: `repo` (полный доступ к репозиториям)
   - Скопируйте новый токен

2. **Настройте аутентификацию:**
   ```bash
   cd /home/msfadmin
   git remote set-url origin https://YOUR_NEW_TOKEN@github.com/nvzar/host-security-homework.git
   git push -u origin main
   ```

### Вариант 3: Через SSH (рекомендуется)

1. **Создайте SSH-ключ:**
   ```bash
   ssh-keygen -t ed25519 -C "your_email@example.com"
   cat ~/.ssh/id_ed25519.pub
   ```

2. **Добавьте ключ в GitHub:**
   - GitHub → Settings → SSH and GPG keys → New SSH key
   - Вставьте содержимое публичного ключа

3. **Используйте SSH URL:**
   ```bash
   cd /home/msfadmin
   git remote set-url origin git@github.com:nvzar/host-security-homework.git
   git push -u origin main
   ```

## Файлы для загрузки

Основные файлы проекта:
- `README.md` - основная документация
- `SUMMARY.md` - итоговый отчет
- `DEPLOYMENT.md` - инструкции по развертыванию
- `task1_ecryptfs.sh` - скрипт для задания 1
- `task2_luks.sh` - скрипт для задания 2
- `task3_apparmor.sh` - скрипт для задания 3

## Проверка загрузки

После успешной загрузки репозиторий будет доступен по адресу:
https://github.com/nvzar/host-security-homework

## Альтернативные платформы

Если возникают проблемы с GitHub, можно использовать:
- GitLab: https://gitlab.com/nvzar/host-security-homework
- Bitbucket: https://bitbucket.org/nvzar/host-security-homework
- Gitea: любой публичный инстанс Gitea
